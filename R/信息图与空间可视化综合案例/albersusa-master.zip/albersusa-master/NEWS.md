0.3.0
* simplefeatures (sf) functions
* `points_elided()` function courtesy of @rdinter

0.1.0 
* Initial release
